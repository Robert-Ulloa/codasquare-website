import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import HeroSection from '@/components/sections/HeroSection'
import ProblemSection from '@/components/sections/ProblemSection'
import SolutionSection from '@/components/sections/SolutionSection'

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <HeroSection />
      <ProblemSection />
      <SolutionSection />
      
      {/* TODO: Add remaining sections */}
      {/* - Features Section (3 tiers) */}
      {/* - How It Works Section (timeline) */}
      {/* - Portfolio Section (case studies) */}
      {/* - Why Custom Section (comparison table) */}
      {/* - Who This Is For Section */}
      {/* - Pricing Section */}
      {/* - About Section */}
      {/* - FAQ Section */}
      {/* - Contact/CTA Section */}
      
      <Footer />
    </main>
  )
}
